#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Benchmark de procesamiento de imágenes con OpenCV.

Proyecto: Experimentación y análisis de prestaciones.
Objetivo: forzar saturación real (CPU y/o RAM) midiendo tiempo, CPU y memoria
al variar resolución, cantidad de imágenes, procesos concurrentes y retención
de buffers.

Matriz ampliada:
    resoluciones: 720p, 1080p, 1440p, 4K y 8K sintético
    cantidades:   50, 100, 200, 400, 600, 1000, 1500, 2000
    repeticiones: 3

Modos de presión:
    - secuencial (1 proceso)
    - concurrente_Nproc (ProcessPoolExecutor, procesos reales, sin GIL)
    - memoria_retenida (no libera los resultados durante la prueba)
    - extremo (kernel/pasadas más agresivos + concurrencia + memoria)

Uso típico:
    pip install opencv-python psutil numpy pandas matplotlib
    python benchmark.py --campana
    python benchmark.py --extremo
    python benchmark.py --procesos 4 --memoria
    python benchmark.py --procesos todos --resoluciones 4K,8K --cantidades 200,600,1000

Salidas (junto a este archivo):
    resultados_benchmark.csv   una fila por ejecución; se agrega sin borrar
    graficas/*.png             gráficas de la sesión (incluye saturación)

Las imágenes son sintéticas y locales (semilla fija). No se descarga nada.
La generación queda fuera del cronómetro: el tiempo medido es solo el pipeline.
"""

from __future__ import annotations

import argparse
import gc
import platform
import shutil
import sys
import threading
import time
from collections.abc import Callable, Iterable
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

try:
    import cv2
    import matplotlib

    # Agg permite guardar PNG sin abrir una ventana (útil en Windows y en sesiones sin escritorio).
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    import pandas as pd
    import psutil
except ImportError as exc:
    print("Falta una dependencia de Python:", exc)
    print("Instálalas con:")
    print("    pip install opencv-python psutil numpy pandas matplotlib")
    raise SystemExit(1) from exc


# ---------------------------------------------------------------------------
# Parámetros del experimento. Cambiarlos aquí altera toda la matriz.
# ---------------------------------------------------------------------------

RESOLUCIONES: dict[str, tuple[int, int]] = {
    "720p": (1280, 720),
    "1080p": (1920, 1080),
    "1440p": (2560, 1440),
    "4K": (3840, 2160),
    "8K": (7680, 4320),
}

# Perfil RÁPIDO por defecto (python benchmark.py): pensado para ~20-30 min
# en un equipo de ~12 núcleos lógicos. 8K queda fuera del preset (úsalo con
# --resoluciones 8K o --completo).
RESOLUCIONES_RAPIDO: dict[str, tuple[int, int]] = {
    "1080p": (1920, 1080),
    "4K": (3840, 2160),
}
CANTIDADES_IMAGENES: list[int] = [50, 100, 200]
CANTIDADES_COMPLETO: list[int] = [50, 100, 200, 400, 600, 1000, 1500, 2000]
REPETICIONES: int = 2

# Si el tiempo medio por imagen crece más de este factor respecto al escenario
# anterior (misma resolución), se imprime aviso de posible saturación.
UMBRAL_SATURACION_TIEMPO: float = 0.40
# Si True, tras detectar saturación en una resolución se salta a la siguiente
# (ahorra horas en matrices largas; el aviso ya quedó en el CSV/consola).
DETENER_ESCALADO_SI_SATURA: bool = True

# Si el ETA estimado de la campaña supera este umbral, se advierte en consola.
UMBRAL_ETA_ADVERTENCIA_MIN: float = 60.0

# Misma semilla en todas las máquinas: las imágenes generadas coinciden byte a byte.
SEMILLA: int = 42

# JPEG es mucho más rápido de generar/leer que PNG y sigue siendo local/reproducible.
FORMATO_IMAGEN: str = ".jpg"
CALIDAD_JPEG: int = 85

# Pipeline base (modo normal). El modo extremo los sobrescribe en tiempo de ejecución.
ESCALA_RESIZE: float = 1.0
KERNEL_GAUSSIANO: tuple[int, int] = (31, 31)
SIGMA_GAUSSIANO: float = 7.0
PASADAS_SUAVIZADO: int = 3
PASADAS_CANNY: int = 1
PASADAS_PIPELINE: int = 5
CANNY_UMBRAL_BAJO: int = 50
CANNY_UMBRAL_ALTO: int = 150

# Perfil "modo extremo" (segunda tanda si con concurrencia aún no satura).
KERNEL_GAUSSIANO_EXTREMO: tuple[int, int] = (51, 51)
SIGMA_GAUSSIANO_EXTREMO: float = 9.0
PASADAS_SUAVIZADO_EXTREMO: int = 4
PASADAS_PIPELINE_EXTREMO: int = 10

# Controles de presión. También se pueden fijar por línea de comandos.
NUM_PROCESOS: int | str = 1  # 1, 2, 4, ... o "todos"
MANTENER_EN_MEMORIA: bool = False
MODO_EXTREMO_PIPELINE: bool = False

# Campaña RÁPIDA (default): secuencial → 4 proc → todos → memoria retenida.
# Con pool persistente + 1080p/4K × [50,100,200] × 2 reps debería caber en
# ~20-30 min en un equipo de 12 núcleos lógicos.
CAMPANA_SATURACION: list[dict[str, object]] = [
    {"num_procesos": 1, "mantener_en_memoria": False, "extremo": False},
    {"num_procesos": 4, "mantener_en_memoria": False, "extremo": False},
    {"num_procesos": "todos", "mantener_en_memoria": False, "extremo": False},
    {"num_procesos": 1, "mantener_en_memoria": True, "extremo": False},
]

# Campaña larga (solo con --campana-completa).
CAMPANA_COMPLETA: list[dict[str, object]] = [
    {"num_procesos": 1, "mantener_en_memoria": False, "extremo": False},
    {"num_procesos": 2, "mantener_en_memoria": False, "extremo": False},
    {"num_procesos": 4, "mantener_en_memoria": False, "extremo": False},
    {"num_procesos": "todos", "mantener_en_memoria": False, "extremo": False},
    {"num_procesos": 1, "mantener_en_memoria": True, "extremo": False},
    {"num_procesos": "todos", "mantener_en_memoria": True, "extremo": True},
]

# Muestreo más fino para no perder picos en tramos cortos.
INTERVALO_MUESTREO_S: float = 0.1

# Compresión: JPEG es mucho más rápido que PNG al generar miles de archivos.
# El tiempo de generación no entra en las métricas del pipeline.
COMPRESION_PNG: int = 1

NOMBRE_CSV: str = "resultados_benchmark.csv"
CARPETA_GRAFICAS: str = "graficas"
CARPETA_TEMPORAL: str = "imagenes_temporales"


def _texto_parametros() -> str:
    """Serializa los parámetros activos del pipeline (cambian en modo extremo)."""
    return (
        f"resize={ESCALA_RESIZE};blur={KERNEL_GAUSSIANO[0]}x{KERNEL_GAUSSIANO[1]};"
        f"sigma={SIGMA_GAUSSIANO};pasadas_blur={PASADAS_SUAVIZADO};"
        f"pasadas_canny={PASADAS_CANNY};pasadas_pipeline={PASADAS_PIPELINE};"
        f"canny={CANNY_UMBRAL_BAJO}-{CANNY_UMBRAL_ALTO}"
    )


PARAMETROS_TEXTO: str = _texto_parametros()

# ram_* suma el RSS del proceso principal y de sus hijos (pools de procesos).
COLUMNAS: list[str] = [
    "id_sesion",
    "id_prueba",
    "marca_tiempo",
    "modo",
    "num_procesos",
    "resolucion",
    "ancho",
    "alto",
    "cantidad_imagenes",
    "megapixeles",
    "tiempo_total_s",
    "tiempo_promedio_imagen_s",
    "imagenes_por_segundo",
    "cpu_promedio_pct",
    "cpu_maximo_pct",
    "ram_inicial_mb",
    "ram_maxima_mb",
    "ram_utilizada_mb",
    "repeticion",
    "imagenes_ok",
    "imagenes_fallidas",
    "muestras_cpu",
    "ram_sistema_inicial_mb",
    "ram_sistema_maxima_mb",
    "ram_sistema_utilizada_mb",
    "nucleos_logicos",
    "mantener_en_memoria",
    "parametros",
]

# Colores y marcadores distinguibles también en una impresión en blanco y negro.
ESTILOS_RESOLUCION: dict[str, dict[str, str]] = {
    "720p": {"color": "#0072B2", "marker": "o"},
    "1080p": {"color": "#E69F00", "marker": "s"},
    "1440p": {"color": "#009E73", "marker": "^"},
    "4K": {"color": "#D55E00", "marker": "D"},
    "8K": {"color": "#CC79A7", "marker": "v"},
}

ESTILOS_MODO: dict[str, dict[str, str]] = {
    "secuencial": {"color": "#0072B2", "marker": "o"},
    "memoria_retenida": {"color": "#D55E00", "marker": "s"},
}

GRAFICAS: list[tuple[str, str, str, str]] = [
    (
        "tiempo_total_s",
        "Tiempo total (s)",
        "Tiempo total vs. cantidad de imágenes",
        "tiempo_total_vs_cantidad.png",
    ),
    (
        "cpu_promedio_pct",
        "CPU promedio (%)",
        "CPU promedio vs. cantidad de imágenes",
        "cpu_promedio_vs_cantidad.png",
    ),
    (
        "ram_utilizada_mb",
        "RAM utilizada (MB)",
        "RAM utilizada vs. cantidad de imágenes",
        "ram_utilizada_vs_cantidad.png",
    ),
    (
        "imagenes_por_segundo",
        "Imágenes por segundo",
        "Imágenes por segundo vs. cantidad de imágenes",
        "imagenes_por_segundo_vs_cantidad.png",
    ),
]


# ---------------------------------------------------------------------------
# Perfil del pipeline (mutable para workers de multiprocessing en Windows).
# ---------------------------------------------------------------------------

_PERFIL_PIPELINE: dict[str, object] = {
    "escala": ESCALA_RESIZE,
    "kernel": KERNEL_GAUSSIANO,
    "sigma": SIGMA_GAUSSIANO,
    "pasadas_suavizado": PASADAS_SUAVIZADO,
    "pasadas_canny": PASADAS_CANNY,
    "pasadas_pipeline": PASADAS_PIPELINE,
    "canny_bajo": CANNY_UMBRAL_BAJO,
    "canny_alto": CANNY_UMBRAL_ALTO,
}


def _aplicar_perfil_pipeline(extremo: bool = False) -> None:
    """Actualiza globals y el dict que heredan los workers vía initializer."""
    global KERNEL_GAUSSIANO, SIGMA_GAUSSIANO, PASADAS_SUAVIZADO
    global PASADAS_PIPELINE, PARAMETROS_TEXTO

    if extremo:
        KERNEL_GAUSSIANO = KERNEL_GAUSSIANO_EXTREMO
        SIGMA_GAUSSIANO = SIGMA_GAUSSIANO_EXTREMO
        PASADAS_SUAVIZADO = PASADAS_SUAVIZADO_EXTREMO
        PASADAS_PIPELINE = PASADAS_PIPELINE_EXTREMO
    else:
        KERNEL_GAUSSIANO = (31, 31)
        SIGMA_GAUSSIANO = 7.0
        PASADAS_SUAVIZADO = 3
        PASADAS_PIPELINE = 5

    PARAMETROS_TEXTO = _texto_parametros()
    _PERFIL_PIPELINE.update(
        {
            "escala": ESCALA_RESIZE,
            "kernel": KERNEL_GAUSSIANO,
            "sigma": SIGMA_GAUSSIANO,
            "pasadas_suavizado": PASADAS_SUAVIZADO,
            "pasadas_canny": PASADAS_CANNY,
            "pasadas_pipeline": PASADAS_PIPELINE,
            "canny_bajo": CANNY_UMBRAL_BAJO,
            "canny_alto": CANNY_UMBRAL_ALTO,
        }
    )


def _resolver_num_procesos(valor: int | str | None) -> int:
    """Convierte 1/2/4/'todos' al entero real de workers."""
    if valor is None:
        return 1
    if isinstance(valor, str):
        texto = valor.strip().lower()
        if texto in {"todos", "all", "max"}:
            return max(1, int(psutil.cpu_count(logical=True) or 1))
        return max(1, int(texto))
    return max(1, int(valor))


def _etiqueta_modo(num_procesos: int, mantener: bool, extremo: bool) -> str:
    """Nombre legible del modo para la columna CSV y las gráficas."""
    if mantener and num_procesos > 1 and extremo:
        return f"extremo_{num_procesos}proc_memoria"
    if mantener and num_procesos > 1:
        return f"concurrente_{num_procesos}proc_memoria"
    if mantener:
        return "memoria_retenida"
    if num_procesos <= 1:
        return "secuencial" if not extremo else "extremo_secuencial"
    if extremo:
        return f"extremo_{num_procesos}proc"
    return f"concurrente_{num_procesos}proc"


def _configurar_consola() -> None:
    """Evita fallos al imprimir acentos en consolas antiguas de Windows."""
    if sys.platform == "win32":
        try:
            import ctypes

            ctypes.windll.kernel32.SetConsoleOutputCP(65001)
            ctypes.windll.kernel32.SetConsoleCP(65001)
        except (AttributeError, OSError):
            pass
    for flujo in (sys.stdout, sys.stderr):
        reconfigurar = getattr(flujo, "reconfigure", None)
        if reconfigurar is None:
            continue
        try:
            reconfigurar(encoding="utf-8", errors="replace")
        except (OSError, ValueError):
            pass


def _a_mb(cantidad_bytes: float) -> float:
    """Convierte bytes a MB binarios (1 MB = 1024 x 1024), como el Administrador de tareas."""
    return float(cantidad_bytes) / (1024 ** 2)


def _barra_progreso(actual: int, total: int, ancho: int = 28) -> str:
    """Barra textual. `actual` es la prueba en curso, contada desde 1."""
    if total <= 0:
        return "[sin pruebas]"
    llenos = min(ancho, max(0, round(ancho * actual / total)))
    porcentaje = 100.0 * actual / total
    return f"[{'#' * llenos}{'-' * (ancho - llenos)}] {actual}/{total} ({porcentaje:.0f}%)"


def _eliminar_directorio(directorio: Path) -> None:
    """Borra la carpeta temporal. Un fallo aquí no invalida el CSV ya escrito."""
    if not directorio.exists():
        return
    try:
        shutil.rmtree(directorio)
    except OSError as exc:
        print(f"No se pudo borrar {directorio}: {exc}", flush=True)


def _escribir_imagen(ruta: Path, imagen: np.ndarray) -> None:
    """
    Guarda una imagen sin usar cv2.imwrite (falla en Windows con rutas no ANSI).

    JPEG por defecto: generar 400–2000 archivos es órdenes de magnitud más
    rápido que PNG y el contenido sigue siendo sintético/local.
    """
    sufijo = ruta.suffix.lower() or FORMATO_IMAGEN
    if sufijo in {".jpg", ".jpeg"}:
        ok, buffer = cv2.imencode(
            ".jpg",
            imagen,
            [int(cv2.IMWRITE_JPEG_QUALITY), CALIDAD_JPEG],
        )
    else:
        ok, buffer = cv2.imencode(
            ".png",
            imagen,
            [cv2.IMWRITE_PNG_COMPRESSION, COMPRESION_PNG],
        )
    if not ok:
        raise OSError(f"OpenCV no pudo codificar la imagen {ruta.name}")
    buffer.tofile(str(ruta))


def _leer_imagen(ruta: Path) -> np.ndarray | None:
    """Carga una imagen desde disco. Devuelve None si el archivo está dañado."""
    try:
        datos = np.fromfile(str(ruta), dtype=np.uint8)
    except OSError:
        return None
    if datos.size == 0:
        return None
    return cv2.imdecode(datos, cv2.IMREAD_COLOR)


def _crear_imagen_sintetica(ancho: int, alto: int, indice: int, semilla: int) -> np.ndarray:
    """
    Construye una escena sintética reproducible: degradado, figuras y ruido en bloques.

    El ruido se genera a baja resolución y se amplía. Así Canny ve textura, pero el
    PNG no se convierte en ruido blanco (que apenas comprime y llena el disco).
    """
    rng = np.random.default_rng(semilla + indice)

    imagen = np.empty((alto, ancho, 3), dtype=np.uint8)
    eje_y = np.linspace(15, 230, alto, dtype=np.uint8)
    imagen[:, :, 0] = eje_y[:, None]
    imagen[:, :, 1] = np.linspace(210, 25, alto, dtype=np.uint8)[:, None]
    imagen[:, :, 2] = np.uint8((40 + indice * 13) % 256)

    for _ in range(12):
        color = tuple(int(canal) for canal in rng.integers(0, 256, size=3))
        x1, x2 = (int(v) for v in rng.integers(0, ancho, size=2))
        y1, y2 = (int(v) for v in rng.integers(0, alto, size=2))
        if x1 == x2:
            x2 = min(ancho - 1, x1 + 1)
        if y1 == y2:
            y2 = min(alto - 1, y1 + 1)
        esquina_1 = (min(x1, x2), min(y1, y2))
        esquina_2 = (max(x1, x2), max(y1, y2))
        if rng.random() < 0.5:
            cv2.rectangle(imagen, esquina_1, esquina_2, color, thickness=-1)
        else:
            centro = (
                (esquina_1[0] + esquina_2[0]) // 2,
                (esquina_1[1] + esquina_2[1]) // 2,
            )
            radio = max(
                1,
                min(esquina_2[0] - esquina_1[0], esquina_2[1] - esquina_1[1]) // 2,
            )
            cv2.circle(imagen, centro, radio, color, thickness=-1)

    for _ in range(8):
        punto_1 = (int(rng.integers(0, ancho)), int(rng.integers(0, alto)))
        punto_2 = (int(rng.integers(0, ancho)), int(rng.integers(0, alto)))
        color = tuple(int(canal) for canal in rng.integers(0, 256, size=3))
        grosor = max(1, ancho // 640)
        cv2.line(imagen, punto_1, punto_2, color, thickness=grosor)

    alto_bajo = max(1, alto // 32)
    ancho_bajo = max(1, ancho // 32)
    ruido_bajo = rng.integers(0, 36, size=(alto_bajo, ancho_bajo, 3), dtype=np.uint8)
    ruido = cv2.resize(ruido_bajo, (ancho, alto), interpolation=cv2.INTER_NEAREST)
    return cv2.add(imagen, ruido)


def generar_imagenes(
    directorio: Path,
    ancho: int,
    alto: int,
    cantidad: int,
    semilla: int = SEMILLA,
) -> list[Path]:
    """
    Genera `cantidad` imágenes en `directorio` y devuelve sus rutas ordenadas.

    Cada archivo depende solo de (semilla, índice, tamaño), así que repetir el
    experimento en otro equipo produce las mismas escenas.
    """
    if cantidad < 1:
        raise ValueError("La cantidad de imágenes debe ser al menos 1.")
    if ancho < 2 or alto < 2:
        raise ValueError(f"Resolución demasiado pequeña: {ancho}x{alto}.")

    directorio.mkdir(parents=True, exist_ok=True)
    rutas: list[Path] = []
    digitos = max(4, len(str(cantidad - 1)))
    paso_log = 50 if cantidad >= 200 else 20

    for indice in range(cantidad):
        ruta = directorio / f"img_{indice:0{digitos}d}{FORMATO_IMAGEN}"
        imagen = _crear_imagen_sintetica(ancho, alto, indice, semilla)
        try:
            _escribir_imagen(ruta, imagen)
        finally:
            del imagen
        rutas.append(ruta)
        if indice == 0 or (indice + 1) % paso_log == 0 or (indice + 1) == cantidad:
            print(f"  Imágenes generadas: {indice + 1}/{cantidad}", flush=True)

    return rutas


def procesar_pipeline(
    fuente: Path | np.ndarray | str,
    al_pico_de_memoria: Callable[[], None] | None = None,
    perfil: dict[str, object] | None = None,
    devolver_entrada: bool = False,
) -> np.ndarray | tuple[np.ndarray, np.ndarray]:
    """
    Aplica el pipeline fijo a una imagen.

    Orden obligatorio del experimento:
        1. Carga (desde disco o array ya en RAM)
        2. Redimensionado
        3. Escala de grises
        4. Suavizado gaussiano (varias pasadas, kernel grande)
        5. Detección de bordes Canny (varias pasadas)

    Si `devolver_entrada=True`, además de los bordes devuelve la imagen BGR
    cargada. Eso permite el modo memoria_retenida: retener el decode completo
    (no solo el mapa de bordes, que es 1 canal y apenas llena la RAM).
    """
    cfg = perfil or _PERFIL_PIPELINE
    escala = float(cfg["escala"])  # type: ignore[arg-type]
    kernel = tuple(cfg["kernel"])  # type: ignore[arg-type]
    sigma = float(cfg["sigma"])  # type: ignore[arg-type]
    pasadas_suavizado = int(cfg["pasadas_suavizado"])  # type: ignore[arg-type]
    pasadas_canny = int(cfg["pasadas_canny"])  # type: ignore[arg-type]
    pasadas_pipeline = int(cfg["pasadas_pipeline"])  # type: ignore[arg-type]
    canny_bajo = int(cfg["canny_bajo"])  # type: ignore[arg-type]
    canny_alto = int(cfg["canny_alto"])  # type: ignore[arg-type]

    etiqueta = "?"
    if isinstance(fuente, np.ndarray):
        imagen = fuente
        etiqueta = "array"
    else:
        ruta = Path(fuente)
        etiqueta = ruta.name
        imagen = _leer_imagen(ruta)
    if imagen is None or imagen.size == 0:
        raise ValueError(f"No se pudo cargar la imagen: {etiqueta}")

    alto, ancho = imagen.shape[:2]
    nuevo_tamano = (
        max(1, int(ancho * escala)),
        max(1, int(alto * escala)),
    )
    # INTER_LINEAR también cuando la escala es 1.0: fuerza un pase completo
    # sobre la imagen y mantiene el coste comparable entre resoluciones.
    interpolacion = cv2.INTER_AREA if escala < 1.0 else cv2.INTER_LINEAR
    redimensionada = cv2.resize(imagen, nuevo_tamano, interpolation=interpolacion)
    gris = cv2.cvtColor(redimensionada, cv2.COLOR_BGR2GRAY)

    # float32: más memoria por píxel y más trabajo en el blur (carga mixta).
    trabajo = gris.astype(np.float32)
    bordes = None
    for _ in range(pasadas_pipeline):
        suavizada = trabajo
        for _ in range(pasadas_suavizado):
            suavizada = cv2.GaussianBlur(suavizada, kernel, sigma)
        # Canny exige 8 bits; la conversión también cuenta en el coste medido.
        suavizada_u8 = cv2.convertScaleAbs(suavizada)
        actual = suavizada_u8
        for _ in range(pasadas_canny):
            actual = cv2.Canny(suavizada_u8, canny_bajo, canny_alto)
        bordes = actual
        # Realimentar el suavizado: la siguiente pasada no trabaja sobre un
        # buffer frío y mantiene la presión sobre la caché/RAM.
        trabajo = suavizada

    if bordes is None:
        raise ValueError(f"El pipeline no produjo bordes: {etiqueta}")

    if al_pico_de_memoria is not None:
        al_pico_de_memoria()
    if devolver_entrada:
        # Copia explícita: si fuente era Path, `imagen` es el decode; hay que
        # retenerlo fuera del scope local.
        return bordes, np.copy(imagen)
    return bordes


def _init_worker(perfil: dict[str, object], hilos_opencv: int) -> None:
    """
    Inicializa cada proceso hijo del pool.

    En Windows el hijo reimporta el módulo y NO hereda cambios del padre:
    por eso el perfil se inyecta aquí. Además se limita OpenCV a 1 hilo por
    proceso para no sobre-suscribir la CPU (N procesos × 12 hilos).
    """
    _PERFIL_PIPELINE.clear()
    _PERFIL_PIPELINE.update(perfil)
    cv2.setUseOptimized(True)
    cv2.setNumThreads(max(1, int(hilos_opencv)))


def _worker_procesar(
    ruta_str: str,
    devolver_array: bool,
) -> tuple[bool, str | None, np.ndarray | None, np.ndarray | None]:
    """Procesa una imagen en un proceso hijo. Debe ser top-level para picklearse."""
    try:
        if devolver_array:
            resultado = procesar_pipeline(
                Path(ruta_str),
                perfil=_PERFIL_PIPELINE,
                devolver_entrada=True,
            )
            bordes, entrada = resultado  # type: ignore[misc]
        else:
            bordes = procesar_pipeline(Path(ruta_str), perfil=_PERFIL_PIPELINE)
            entrada = None
    except Exception as exc:  # no tumbar el pool por una imagen
        return False, str(exc), None, None
    if bordes is None or getattr(bordes, "size", 0) == 0:
        return False, "sin bordes", None, None
    if devolver_array:
        return True, None, bordes, entrada  # type: ignore[return-value]
    return True, None, None, None


class MonitorRecursos:
    """
    Muestrea CPU y RAM en un hilo mientras el hilo principal procesa imágenes.

    CPU: psutil.cpu_percent(interval=intervalo). Con interval > 0 la llamada
    bloquea durante esa ventana y devuelve el uso del sistema en ese tramo.
    No depende de una llamada anterior, así que cada muestra es independiente.

    RAM del proceso: RSS del proceso principal + RSS de hijos recursivos
    (ProcessPoolExecutor). Sin sumar hijos, la RAM concurrente quedaría
    subestimada.
    RAM del sistema: psutil.virtual_memory().used. Incluye otros programas.
    """

    def __init__(self, intervalo: float) -> None:
        if intervalo <= 0:
            raise ValueError("El intervalo de muestreo debe ser mayor que 0.")
        self.intervalo = intervalo
        self._detener = threading.Event()
        self._hilo: threading.Thread | None = None
        self._lock = threading.Lock()
        self._proceso = psutil.Process()
        self.cpus: list[float] = []
        self.rams_proceso: list[int] = []
        self.rams_sistema: list[int] = []
        self.ram_proceso_inicial: int = 0
        self.ram_sistema_inicial: int = 0
        self.error: Exception | None = None

    def _rss_arbol(self) -> int:
        """RSS del proceso actual más todos los hijos vivos (recursivo)."""
        total = 0
        try:
            total += int(self._proceso.memory_info().rss)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            return total
        try:
            hijos = self._proceso.children(recursive=True)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return total
        for hijo in hijos:
            try:
                total += int(hijo.memory_info().rss)
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
        return total

    def iniciar(self) -> MonitorRecursos:
        """Libera basura de Python, anota la RAM base y arranca el muestreador."""
        gc.collect()
        self.ram_proceso_inicial = self._rss_arbol()
        self.ram_sistema_inicial = psutil.virtual_memory().used
        self._hilo = threading.Thread(
            target=self._muestrear,
            name="muestreador-cpu-ram",
            daemon=True,
        )
        self._hilo.start()
        return self

    def _muestrear(self) -> None:
        """
        Toma ventanas completas de CPU mientras la prueba sigue en curso.

        Si la prueba termina a mitad de una ventana y ya hay muestras, esa
        ventana se descarta: mezclaría trabajo con el tiempo ya inactivo.
        Si la prueba duró menos que una ventana, se conserva la única muestra
        para no dejar la fila sin datos de CPU.
        """
        try:
            while True:
                cpu = psutil.cpu_percent(interval=self.intervalo)
                ram_sistema = psutil.virtual_memory().used
                ram_proceso = self._rss_arbol()
                termino = self._detener.is_set()
                if termino and self.cpus:
                    break
                with self._lock:
                    self.cpus.append(float(cpu))
                    self.rams_sistema.append(int(ram_sistema))
                    self.rams_proceso.append(int(ram_proceso))
                if termino:
                    break
        except Exception as exc:  # el hilo no debe tumbar el proceso en silencio
            self.error = exc

    def detener(self) -> dict[str, float]:
        """Detiene el hilo y resume promedio, máximo y deltas de RAM."""
        self._detener.set()
        if self._hilo is not None:
            self._hilo.join()
        if self.error is not None:
            print(f"  Aviso: el muestreador terminó con error: {self.error}", flush=True)
        return self._resumen()

    def registrar_pico(self) -> None:
        """
        Anota la RAM residente (árbol de procesos) con buffers todavía vivos.

        El hilo de fondo muestrea cada 0.1 s y puede caer entre dos imágenes,
        cuando esos buffers ya se liberaron. Esta lectura captura el pico real.
        """
        rss = self._rss_arbol()
        with self._lock:
            self.rams_proceso.append(int(rss))

    def _resumen(self) -> dict[str, float]:
        if self.cpus:
            cpu_promedio = float(np.mean(self.cpus))
            cpu_maximo = float(np.max(self.cpus))
        else:
            cpu_promedio = float("nan")
            cpu_maximo = float("nan")

        ram_proceso_maxima = max([self.ram_proceso_inicial, *self.rams_proceso])
        ram_sistema_maxima = max([self.ram_sistema_inicial, *self.rams_sistema])

        return {
            "cpu_promedio_pct": cpu_promedio,
            "cpu_maximo_pct": cpu_maximo,
            "muestras_cpu": float(len(self.cpus)),
            "ram_inicial_mb": _a_mb(self.ram_proceso_inicial),
            "ram_maxima_mb": _a_mb(ram_proceso_maxima),
            "ram_utilizada_mb": _a_mb(ram_proceso_maxima - self.ram_proceso_inicial),
            "ram_sistema_inicial_mb": _a_mb(self.ram_sistema_inicial),
            "ram_sistema_maxima_mb": _a_mb(ram_sistema_maxima),
            "ram_sistema_utilizada_mb": _a_mb(ram_sistema_maxima - self.ram_sistema_inicial),
        }


def medir_recursos(intervalo: float = INTERVALO_MUESTREO_S) -> MonitorRecursos:
    """Arranca el muestreo en segundo plano y devuelve el monitor ya iniciado."""
    return MonitorRecursos(intervalo).iniciar()


def _crear_pool(num_procesos: int) -> ProcessPoolExecutor:
    """
    Crea el pool de procesos UNA vez por modo.

    En Windows (spawn) cada worker reimporta cv2/numpy/pandas: hacerlo por
    cada prueba distorsionaba el CPU% y alargaba la campaña horas.
    """
    return ProcessPoolExecutor(
        max_workers=max(1, int(num_procesos)),
        initializer=_init_worker,
        initargs=(dict(_PERFIL_PIPELINE), 1),
    )


def _procesar_secuencial(
    rutas: list[Path],
    monitor: MonitorRecursos,
    mantener_en_memoria: bool,
) -> tuple[int, int, list[np.ndarray]]:
    """Procesa imagen a imagen en el proceso actual."""
    ok = 0
    fallidas = 0
    retenidas: list[np.ndarray] = []
    for ruta in rutas:
        try:
            if mantener_en_memoria:
                resultado = procesar_pipeline(
                    ruta, monitor.registrar_pico, devolver_entrada=True
                )
                bordes, entrada = resultado  # type: ignore[misc]
            else:
                bordes = procesar_pipeline(ruta, monitor.registrar_pico)
                entrada = None
        except Exception as exc:
            fallidas += 1
            print(f"    Error en {ruta.name}: {exc}", flush=True)
            continue
        if not isinstance(bordes, np.ndarray) or bordes.size == 0:
            fallidas += 1
            print(f"    {ruta.name} no produjo bordes.", flush=True)
            continue
        ok += 1
        if mantener_en_memoria:
            # Retener bordes + BGR completo: en 4K/8K la RAM crece con la
            # cantidad hasta acercarse al límite del equipo (thrashing).
            retenidas.append(bordes)
            if entrada is not None:
                retenidas.append(entrada)
            monitor.registrar_pico()
        else:
            del bordes
    return ok, fallidas, retenidas


def _procesar_concurrente(
    rutas: list[Path],
    monitor: MonitorRecursos,
    mantener_en_memoria: bool,
    pool: ProcessPoolExecutor,
) -> tuple[int, int, list[np.ndarray]]:
    """
    Procesa con un ProcessPoolExecutor YA creado (persistente por modo).

    No crea ni destruye el pool aquí: eso debe hacerse una sola vez en
    correr_matriz_experimentos. Cada worker usa 1 hilo de OpenCV.
    """
    ok = 0
    fallidas = 0
    retenidas: list[np.ndarray] = []

    futuros = {
        pool.submit(_worker_procesar, str(ruta), mantener_en_memoria): ruta
        for ruta in rutas
    }
    for futuro in as_completed(futuros):
        ruta = futuros[futuro]
        try:
            exito, error, array, entrada = futuro.result()
        except Exception as exc:
            fallidas += 1
            print(f"    Error en {ruta.name}: {exc}", flush=True)
            continue
        if not exito:
            fallidas += 1
            print(f"    Error en {ruta.name}: {error}", flush=True)
            continue
        ok += 1
        if mantener_en_memoria:
            if array is not None:
                retenidas.append(array)
            if entrada is not None:
                retenidas.append(entrada)
        monitor.registrar_pico()

    return ok, fallidas, retenidas


def ejecutar_prueba(
    rutas: list[Path],
    resolucion: str,
    ancho: int,
    alto: int,
    repeticion: int,
    id_sesion: str,
    intervalo: float = INTERVALO_MUESTREO_S,
    num_procesos: int = 1,
    mantener_en_memoria: bool = False,
    modo: str | None = None,
    pool: ProcessPoolExecutor | None = None,
) -> dict[str, object]:
    """
    Ejecuta el pipeline sobre `rutas`, mide tiempo y recursos, y devuelve una fila.

    Un archivo dañado no aborta la prueba: se cuenta en `imagenes_fallidas` y
    se continúa con la imagen siguiente. El tiempo total incluye esos intentos.
    El promedio y las imágenes/segundo usan solo las imágenes que sí se procesaron.

    Con num_procesos > 1 se reutiliza `pool` (ProcessPoolExecutor persistente).
    Con mantener_en_memoria los arrays de salida se acumulan hasta el final.

    Nota sobre RAM en concurrente: el monitor suma RSS del padre + hijos.
    Cada proceso trae su propio intérprete/buffers, así que ram_utilizada_mb
    NO es comparable 1:1 con el modo secuencial; para una lectura "por unidad
    de trabajo" divide entre num_procesos en el resumen (no en el CSV crudo).
    """
    num_procesos = max(1, int(num_procesos))
    modo_txt = modo or _etiqueta_modo(num_procesos, mantener_en_memoria, MODO_EXTREMO_PIPELINE)
    imagenes_ok = 0
    imagenes_fallidas = 0
    retenidas: list[np.ndarray] = []

    if num_procesos > 1 and pool is None:
        raise ValueError(
            "Modo concurrente sin pool persistente: pásalo desde "
            "correr_matriz_experimentos (no crear un pool por prueba)."
        )

    monitor = medir_recursos(intervalo)
    inicio = time.perf_counter()
    try:
        if num_procesos <= 1:
            imagenes_ok, imagenes_fallidas, retenidas = _procesar_secuencial(
                rutas, monitor, mantener_en_memoria
            )
        else:
            assert pool is not None
            imagenes_ok, imagenes_fallidas, retenidas = _procesar_concurrente(
                rutas, monitor, mantener_en_memoria, pool
            )
        # Forzar un pico final con todo lo retenido todavía vivo.
        if retenidas:
            monitor.registrar_pico()
        tiempo_total = time.perf_counter() - inicio
    finally:
        # Aunque la prueba se interrumpa, el hilo de muestreo tiene que cerrarse.
        recursos = monitor.detener()
        # Liberar después de medir: si no, contaminaría la siguiente repetición.
        retenidas.clear()
        gc.collect()

    if imagenes_ok > 0 and tiempo_total > 0:
        tiempo_promedio = tiempo_total / imagenes_ok
        imagenes_por_segundo = imagenes_ok / tiempo_total
    else:
        tiempo_promedio = float("nan")
        imagenes_por_segundo = float("nan")

    if tiempo_total < 2 * intervalo:
        print(
            "    Aviso: la prueba duró menos que dos intervalos de muestreo; "
            "el % de CPU tiene pocas muestras y es menos preciso.",
            flush=True,
        )

    fila: dict[str, object] = {
        "id_sesion": id_sesion,
        "id_prueba": f"{modo_txt}_{resolucion}_n{len(rutas)}_p{num_procesos}_r{repeticion}",
        "marca_tiempo": datetime.now().isoformat(timespec="seconds"),
        "modo": modo_txt,
        "num_procesos": num_procesos,
        "resolucion": resolucion,
        "ancho": ancho,
        "alto": alto,
        "cantidad_imagenes": len(rutas),
        "megapixeles": round((ancho * alto) / 1_000_000, 4),
        "tiempo_total_s": round(tiempo_total, 6),
        "tiempo_promedio_imagen_s": (
            round(tiempo_promedio, 6) if tiempo_promedio == tiempo_promedio else tiempo_promedio
        ),
        "imagenes_por_segundo": (
            round(imagenes_por_segundo, 4)
            if imagenes_por_segundo == imagenes_por_segundo
            else imagenes_por_segundo
        ),
        "cpu_promedio_pct": round(recursos["cpu_promedio_pct"], 3),
        "cpu_maximo_pct": round(recursos["cpu_maximo_pct"], 3),
        "ram_inicial_mb": round(recursos["ram_inicial_mb"], 3),
        "ram_maxima_mb": round(recursos["ram_maxima_mb"], 3),
        "ram_utilizada_mb": round(recursos["ram_utilizada_mb"], 3),
        "repeticion": repeticion,
        "imagenes_ok": imagenes_ok,
        "imagenes_fallidas": imagenes_fallidas,
        "muestras_cpu": int(recursos["muestras_cpu"]),
        "ram_sistema_inicial_mb": round(recursos["ram_sistema_inicial_mb"], 3),
        "ram_sistema_maxima_mb": round(recursos["ram_sistema_maxima_mb"], 3),
        "ram_sistema_utilizada_mb": round(recursos["ram_sistema_utilizada_mb"], 3),
        "nucleos_logicos": psutil.cpu_count(logical=True) or 0,
        "mantener_en_memoria": bool(mantener_en_memoria),
        "parametros": PARAMETROS_TEXTO,
    }

    print(
        f"    {fila['id_prueba']}: tiempo={_fmt(fila['tiempo_total_s'], 3)} s | "
        f"{_fmt(_ms(fila['tiempo_promedio_imagen_s']), 2)} ms/img | "
        f"{_fmt(fila['imagenes_por_segundo'], 2)} img/s | "
        f"CPU prom={_fmt(fila['cpu_promedio_pct'], 1)}% max={_fmt(fila['cpu_maximo_pct'], 1)}% | "
        f"RAM util={_fmt(fila['ram_utilizada_mb'], 1)} MB | "
        f"modo={modo_txt} | procs={num_procesos}",
        flush=True,
    )
    if num_procesos > 1:
        ram_pp = float(fila["ram_utilizada_mb"]) / num_procesos  # type: ignore[arg-type]
        print(
            f"      (RAM/proceso ≈ {ram_pp:.1f} MB; la RAM total concurrente "
            "no es comparable 1:1 con secuencial)",
            flush=True,
        )
    return fila


def _fmt(valor: object, decimales: int) -> str:
    """Formatea un número para la consola. NaN o texto no numérico salen como n/d."""
    try:
        numero = float(valor)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return "n/d"
    if numero != numero:
        return "n/d"
    return f"{numero:.{decimales}f}"


def _ms(segundos: object) -> float:
    """Pasa segundos a milisegundos. NaN se conserva para que _fmt lo muestre como n/d."""
    try:
        numero = float(segundos)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return float("nan")
    return numero * 1000.0


def _leer_cabecera_csv(ruta_csv: Path) -> list[str] | None:
    """Lee la cabecera del CSV o None si el archivo no existe / está vacío."""
    if not ruta_csv.exists() or ruta_csv.stat().st_size == 0:
        return None
    try:
        with ruta_csv.open("r", encoding="utf-8-sig", newline="") as handle:
            primera = handle.readline()
    except OSError:
        return None
    if not primera.strip():
        return None
    # csv.reader maneja comillas; split simple basta para nuestra cabecera plana.
    return [c.strip() for c in primera.strip().split(",")]


def _asegurar_csv_compatible(ruta_csv: Path) -> None:
    """
    Si el CSV existente no coincide con COLUMNAS, lo respalda y empieza limpio.

    Evita el caso en que filas nuevas de 28 campos se appendean a un CSV viejo
    de 25 columnas y pd.read_csv revienta al generar gráficas.
    """
    cabecera = _leer_cabecera_csv(ruta_csv)
    if cabecera is None:
        return
    if cabecera == COLUMNAS:
        return
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    respaldo = ruta_csv.with_name(f"resultados_benchmark_backup_{stamp}.csv")
    ruta_csv.rename(respaldo)
    print(
        f"\nAVISO: la cabecera del CSV no coincide con esta versión del script "
        f"({len(cabecera)} cols vs {len(COLUMNAS)}).\n"
        f"  CSV antiguo respaldado en: {respaldo}\n"
        f"  Se iniciará un CSV limpio con la cabecera actual.\n",
        flush=True,
    )


def guardar_resultados(fila: dict[str, object], ruta_csv: Path) -> None:
    """
    Agrega una fila al CSV. Si el archivo no existe, escribe también la cabecera.

    Antes de escribir, comprueba que la cabecera existente coincida con COLUMNAS;
    si no, respalda el archivo y empieza uno nuevo (ver _asegurar_csv_compatible).
    """
    ruta_csv.parent.mkdir(parents=True, exist_ok=True)
    _asegurar_csv_compatible(ruta_csv)
    escribir_cabecera = (not ruta_csv.exists()) or ruta_csv.stat().st_size == 0
    tabla = pd.DataFrame([fila], columns=COLUMNAS)
    tabla.to_csv(
        ruta_csv,
        mode="a",
        header=escribir_cabecera,
        index=False,
        encoding="utf-8-sig" if escribir_cabecera else "utf-8",
    )


def _advertir_modo_extremo(
    resoluciones: dict[str, tuple[int, int]],
    cantidades: list[int],
    num_procesos: int,
    mantener: bool,
    extremo: bool,
) -> None:
    """Aviso claro antes de cargas que pueden congelar el equipo."""
    hay_8k = any(nombre.upper() == "8K" for nombre in resoluciones)
    carga_alta = (
        max(cantidades) >= 1000
        or hay_8k
        or num_procesos >= 4
        or (mantener and max(cantidades) >= 200)
        or extremo
    )
    if not carga_alta:
        return
    print(
        "\n"
        "====================================================================\n"
        "  ADVERTENCIA — MODO DE ALTA PRESIÓN\n"
        "====================================================================\n"
        f"  Resoluciones: {', '.join(resoluciones)}\n"
        f"  Cantidad máxima: {max(cantidades)} imágenes\n"
        f"  Procesos: {num_procesos} | Memoria retenida: {mantener} | "
        f"Pipeline extremo: {extremo}\n"
        "  El equipo puede volverse lento o dejar de responder unos minutos.\n"
        "  Guarda tu trabajo y cierra navegadores, juegos y VMs.\n"
        "  Cada fila se escribe al CSV en cuanto termina (no se pierde todo\n"
        "  si tienes que forzar el cierre).\n"
        "====================================================================\n",
        flush=True,
    )


def correr_matriz_experimentos(
    ruta_csv: Path,
    id_sesion: str,
    directorio_trabajo: Path | None = None,
    resoluciones: dict[str, tuple[int, int]] | None = None,
    cantidades: list[int] | None = None,
    repeticiones: int | None = None,
    intervalo_muestreo: float | None = None,
    num_procesos: int | str | None = None,
    mantener_en_memoria: bool | None = None,
    extremo: bool | None = None,
    modo: str | None = None,
) -> float:
    """
    Recorre la matriz con tres bucles anidados: resolución, cantidad y repetición.

    El ProcessPoolExecutor (si num_procesos > 1) se crea UNA sola vez al inicio
    del modo, se calienta con la primera imagen y se cierra al terminar el modo.
    Devuelve los segundos de pared que duró el modo (para ETA de la campaña).
    """
    base = directorio_trabajo or Path(__file__).resolve().parent
    resoluciones = resoluciones or RESOLUCIONES
    cantidades = list(cantidades or CANTIDADES_IMAGENES)
    repeticiones = REPETICIONES if repeticiones is None else repeticiones
    intervalo = INTERVALO_MUESTREO_S if intervalo_muestreo is None else intervalo_muestreo
    procs = _resolver_num_procesos(
        NUM_PROCESOS if num_procesos is None else num_procesos
    )
    mantener = MANTENER_EN_MEMORIA if mantener_en_memoria is None else bool(mantener_en_memoria)
    usar_extremo = MODO_EXTREMO_PIPELINE if extremo is None else bool(extremo)
    _aplicar_perfil_pipeline(usar_extremo)
    modo_txt = modo or _etiqueta_modo(procs, mantener, usar_extremo)

    if repeticiones < 1:
        raise ValueError("Debe haber al menos una repetición.")
    if not cantidades or any(cantidad < 1 for cantidad in cantidades):
        raise ValueError("Todas las cantidades de imágenes deben ser >= 1.")

    _asegurar_csv_compatible(ruta_csv)
    _advertir_modo_extremo(resoluciones, cantidades, procs, mantener, usar_extremo)

    total = len(resoluciones) * len(cantidades) * repeticiones
    hechas = 0
    tiempos_prueba: list[float] = []
    carpeta_temporal = base / CARPETA_TEMPORAL
    pool: ProcessPoolExecutor | None = None
    pool_calentado = False
    inicio_modo = time.perf_counter()

    print(
        f"\nMatriz [{modo_txt}]: {len(resoluciones)} resoluciones x {len(cantidades)} "
        f"cantidades x {repeticiones} repeticiones = {total} pruebas | "
        f"procesos={procs} | memoria_retenida={mantener}",
        flush=True,
    )
    print(
        f"Pipeline: {PARAMETROS_TEXTO}\n"
        "La generación de imágenes no entra en el tiempo medido. "
        "Cada fila se escribe en el CSV al terminar.",
        flush=True,
    )
    if procs > 1:
        print(
            f"Creando pool persistente de {procs} procesos (una sola vez en este modo)...",
            flush=True,
        )
        print(
            "  Nota RAM: con N procesos la RAM medida es la suma padre+hijos "
            "(cada hijo trae su intérprete). No compares 1:1 con secuencial; "
            "usa RAM/proceso del resumen.",
            flush=True,
        )
        pool = _crear_pool(procs)

    try:
        for nombre, (ancho, alto) in resoluciones.items():
            n_generar = max(cantidades)
            carpeta_resolucion = carpeta_temporal / nombre
            print(
                f"\nPreparando {n_generar} imágenes {nombre} ({ancho}x{alto}, "
                f"{(ancho * alto) / 1_000_000:.2f} Mpx). "
                "Esto no forma parte del cronómetro.",
                flush=True,
            )
            _eliminar_directorio(carpeta_resolucion)
            try:
                rutas_todas = generar_imagenes(
                    carpeta_resolucion,
                    ancho,
                    alto,
                    n_generar,
                    SEMILLA,
                )
            except Exception as exc:
                print(
                    f"No se pudieron generar las imágenes {nombre}: {exc}. "
                    "Se omite esta resolución.",
                    flush=True,
                )
                _eliminar_directorio(carpeta_resolucion)
                hechas += len(cantidades) * repeticiones
                continue

            # Calentamiento: una sola vez por modo (pool persistente o OpenCV local).
            if not pool_calentado:
                print("  Calentando pipeline (no se registra)...", flush=True)
                try:
                    if pool is None:
                        procesar_pipeline(rutas_todas[0])
                    else:
                        pool.submit(
                            _worker_procesar, str(rutas_todas[0]), False
                        ).result()
                    pool_calentado = True
                except Exception as exc:
                    print(f"  El calentamiento falló ({exc}). Se continúa.", flush=True)
                    pool_calentado = True

            tpi_anterior: float | None = None

            try:
                for idx_cant, cantidad in enumerate(cantidades):
                    lote = rutas_todas[:cantidad]
                    tpis_reps: list[float] = []
                    for repeticion in range(1, repeticiones + 1):
                        hechas += 1
                        print(
                            f"{_barra_progreso(hechas, total)} "
                            f"Ejecutando: {nombre}, {cantidad} imágenes, "
                            f"repetición {repeticion}/{repeticiones} | modo={modo_txt}",
                            flush=True,
                        )
                        t0_prueba = time.perf_counter()
                        try:
                            fila = ejecutar_prueba(
                                lote,
                                nombre,
                                ancho,
                                alto,
                                repeticion,
                                id_sesion,
                                intervalo,
                                num_procesos=procs,
                                mantener_en_memoria=mantener,
                                modo=modo_txt,
                                pool=pool,
                            )
                        except Exception as exc:
                            print(
                                f"    La prueba falló y se continúa con la siguiente: {exc}",
                                flush=True,
                            )
                            continue
                        dt_prueba = time.perf_counter() - t0_prueba
                        tiempos_prueba.append(dt_prueba)

                        if len(tiempos_prueba) == 1:
                            restantes = total - hechas
                            eta_s = dt_prueba * restantes
                            print(
                                f"  ETA aproximado para este modo: "
                                f"{eta_s / 60.0:.1f} min "
                                f"({restantes} pruebas restantes, "
                                f"basado en la 1ª prueba = {dt_prueba:.1f} s).",
                                flush=True,
                            )
                            if eta_s / 60.0 > UMBRAL_ETA_ADVERTENCIA_MIN:
                                print(
                                    f"  ADVERTENCIA: el ETA de ESTE modo supera "
                                    f"{UMBRAL_ETA_ADVERTENCIA_MIN:.0f} min. "
                                    "Considera cancelar (Ctrl+C) y acotar con "
                                    "--resoluciones 1080p --cantidades 50,100 "
                                    "--repeticiones 1",
                                    flush=True,
                                )
                        elif hechas % max(1, total // 4) == 0 and hechas < total:
                            promedio = float(np.mean(tiempos_prueba))
                            eta_s = promedio * (total - hechas)
                            print(
                                f"  ETA actualizado (este modo): {eta_s / 60.0:.1f} min "
                                f"restantes (promedio {promedio:.1f} s/prueba).",
                                flush=True,
                            )

                        tpi = fila.get("tiempo_promedio_imagen_s")
                        try:
                            tpi_f = float(tpi)  # type: ignore[arg-type]
                            if tpi_f == tpi_f:
                                tpis_reps.append(tpi_f)
                        except (TypeError, ValueError):
                            pass
                        try:
                            guardar_resultados(fila, ruta_csv)
                        except PermissionError:
                            print(
                                "    No se pudo escribir el CSV. Ciérralo si lo tienes "
                                f"abierto en Excel: {ruta_csv}",
                                flush=True,
                            )
                            print(f"    Fila no guardada: {fila}", flush=True)
                        except OSError as exc:
                            print(f"    No se pudo escribir el CSV: {exc}", flush=True)
                            print(f"    Fila no guardada: {fila}", flush=True)

                    if tpis_reps:
                        tpi_actual = float(np.mean(tpis_reps))
                        if tpi_anterior is not None and tpi_anterior > 0:
                            crecimiento = (tpi_actual - tpi_anterior) / tpi_anterior
                            if crecimiento > UMBRAL_SATURACION_TIEMPO:
                                print(
                                    f"  >>> Posible saturación detectada en {nombre}: "
                                    f"tiempo/imagen subió {crecimiento * 100:.1f}% "
                                    f"al pasar a {cantidad} imágenes "
                                    f"({tpi_anterior * 1000:.2f} → {tpi_actual * 1000:.2f} ms/img).",
                                    flush=True,
                                )
                                if DETENER_ESCALADO_SI_SATURA:
                                    saltadas = len(cantidades) - idx_cant - 1
                                    hechas += saltadas * repeticiones
                                    print(
                                        f"  >>> Se detiene el escalado de cantidad en {nombre} "
                                        f"(faltaban {saltadas} niveles). "
                                        "Pasa a la siguiente resolución. "
                                        "Usa --sin-corte para forzar toda la matriz.",
                                        flush=True,
                                    )
                                    break
                        tpi_anterior = tpi_actual
            finally:
                print(f"  Eliminando imágenes temporales de {nombre}...", flush=True)
                _eliminar_directorio(carpeta_resolucion)
    finally:
        if pool is not None:
            print(
                f"Cerrando pool persistente de {procs} procesos...",
                flush=True,
            )
            pool.shutdown(wait=True, cancel_futures=False)
        _eliminar_directorio(carpeta_temporal)

    duracion = time.perf_counter() - inicio_modo
    print(
        f"Modo [{modo_txt}] terminado en {duracion / 60.0:.1f} min "
        f"({duracion:.0f} s).",
        flush=True,
    )
    return duracion


def _promedios_de_sesion(
    tabla: pd.DataFrame,
    claves: list[str] | None = None,
) -> pd.DataFrame:
    """Promedia las repeticiones agrupando por las claves indicadas."""
    metricas = [
        "tiempo_total_s",
        "cpu_promedio_pct",
        "ram_utilizada_mb",
        "imagenes_por_segundo",
        "tiempo_promedio_imagen_s",
    ]
    metricas = [m for m in metricas if m in tabla.columns]
    group_keys = claves or ["resolucion", "cantidad_imagenes"]
    group_keys = [k for k in group_keys if k in tabla.columns]
    return tabla.groupby(group_keys, as_index=False)[metricas].mean()


def _ordenar_resoluciones(nombres: Iterable[str]) -> list[str]:
    conocidos = [n for n in RESOLUCIONES if n in set(nombres)]
    otros = [n for n in nombres if n not in conocidos]
    return conocidos + list(otros)


def _grafica_lineas_resolucion(
    resumen: pd.DataFrame,
    columna: str,
    eje_y: str,
    titulo: str,
    destino: Path,
) -> None:
    """Una línea por resolución frente a cantidad de imágenes."""
    cantidades = sorted(int(v) for v in resumen["cantidad_imagenes"].unique())
    orden = _ordenar_resoluciones(resumen["resolucion"].unique())
    figura, ejes = plt.subplots(figsize=(10, 6))
    for nombre in orden:
        serie = resumen[resumen["resolucion"] == nombre].sort_values("cantidad_imagenes")
        estilo = ESTILOS_RESOLUCION.get(nombre, {"color": "#333333", "marker": "o"})
        ejes.plot(
            serie["cantidad_imagenes"],
            serie[columna],
            label=nombre,
            color=estilo["color"],
            marker=estilo["marker"],
            linewidth=2,
            markersize=7,
        )
    ejes.set_title(f"{titulo}\n(promedio de las repeticiones)")
    ejes.set_xlabel("Cantidad de imágenes")
    ejes.set_ylabel(eje_y)
    ejes.set_xticks(cantidades)
    ejes.set_ylim(bottom=0)
    if columna == "cpu_promedio_pct":
        ejes.set_ylim(0, 100)
    ejes.grid(True, alpha=0.35)
    ejes.legend(title="Resolución")
    figura.tight_layout()
    figura.savefig(destino, dpi=140, bbox_inches="tight")
    plt.close(figura)
    print(f"Gráfica guardada: {destino}", flush=True)


def _grafica_cpu_vs_procesos(tabla: pd.DataFrame, destino: Path) -> None:
    """
    CPU promedio vs. número de procesos (una línea por resolución).

    Evidencia de saturación: cuando subir procesos ya no sube la CPU (o baja
    el throughput), hay contención o techo de CPU.
    """
    if "num_procesos" not in tabla.columns or "cpu_promedio_pct" not in tabla.columns:
        print("Sin columnas num_procesos/cpu; se omite gráfica CPU vs procesos.", flush=True)
        return
    # Solo modos sin retención de memoria, para aislar el efecto de la concurrencia.
    datos = tabla.copy()
    if "mantener_en_memoria" in datos.columns:
        datos = datos[datos["mantener_en_memoria"].astype(str).isin(["False", "false", "0"])]
    if datos.empty:
        datos = tabla
    resumen = _promedios_de_sesion(
        datos, ["resolucion", "num_procesos"]
    )
    if resumen.empty:
        return
    figura, ejes = plt.subplots(figsize=(10, 6))
    for nombre in _ordenar_resoluciones(resumen["resolucion"].unique()):
        serie = resumen[resumen["resolucion"] == nombre].sort_values("num_procesos")
        estilo = ESTILOS_RESOLUCION.get(nombre, {"color": "#333333", "marker": "o"})
        ejes.plot(
            serie["num_procesos"],
            serie["cpu_promedio_pct"],
            label=nombre,
            color=estilo["color"],
            marker=estilo["marker"],
            linewidth=2,
            markersize=7,
        )
    ejes.set_title(
        "CPU promedio vs. número de procesos\n"
        "(promedio de repeticiones; evidencia de saturación / contención)"
    )
    ejes.set_xlabel("Número de procesos")
    ejes.set_ylabel("CPU promedio (%)")
    ejes.set_ylim(0, 100)
    ejes.grid(True, alpha=0.35)
    ejes.legend(title="Resolución")
    figura.tight_layout()
    figura.savefig(destino, dpi=140, bbox_inches="tight")
    plt.close(figura)
    print(f"Gráfica guardada: {destino}", flush=True)


def _grafica_ram_secuencial_vs_retenida(tabla: pd.DataFrame, destino: Path) -> None:
    """
    RAM utilizada vs. cantidad, comparando secuencial vs memoria_retenida.

    Si la curva retenida crece con la cantidad y la secuencial se queda plana,
    la retención de buffers es el factor memory-bound.
    """
    if "modo" not in tabla.columns or "ram_utilizada_mb" not in tabla.columns:
        print("Sin columnas modo/ram; se omite gráfica RAM comparativa.", flush=True)
        return

    modos_interes = []
    for candidato in ("secuencial", "memoria_retenida"):
        if (tabla["modo"].astype(str) == candidato).any():
            modos_interes.append(candidato)
    # Aceptar también etiquetas extremo_*_memoria como "retenida".
    if not modos_interes:
        print("No hay filas secuencial/memoria_retenida para la gráfica comparativa.", flush=True)
        return

    figura, ejes = plt.subplots(figsize=(10, 6))
    for modo_nombre in modos_interes:
        sub = tabla[tabla["modo"].astype(str) == modo_nombre]
        resumen = _promedios_de_sesion(sub, ["cantidad_imagenes"])
        estilo = ESTILOS_MODO.get(modo_nombre, {"color": "#333333", "marker": "o"})
        ejes.plot(
            resumen["cantidad_imagenes"],
            resumen["ram_utilizada_mb"],
            label=modo_nombre,
            color=estilo["color"],
            marker=estilo["marker"],
            linewidth=2,
            markersize=7,
        )
    # Si hay modos extremo_*memoria, añadir la media global de esos modos.
    mascara_ext = tabla["modo"].astype(str).str.contains("memoria", case=False, na=False)
    mascara_ext &= ~tabla["modo"].astype(str).isin(modos_interes)
    if mascara_ext.any():
        sub = tabla[mascara_ext]
        resumen = _promedios_de_sesion(sub, ["cantidad_imagenes"])
        ejes.plot(
            resumen["cantidad_imagenes"],
            resumen["ram_utilizada_mb"],
            label="otros_modos_memoria",
            color="#CC79A7",
            marker="v",
            linewidth=2,
            markersize=7,
            linestyle="--",
        )

    ejes.set_title(
        "RAM utilizada vs. cantidad de imágenes\n"
        "(secuencial vs memoria_retenida; promedio de repeticiones)"
    )
    ejes.set_xlabel("Cantidad de imágenes")
    ejes.set_ylabel("RAM utilizada (MB)")
    ejes.set_ylim(bottom=0)
    ejes.grid(True, alpha=0.35)
    ejes.legend(title="Modo")
    figura.tight_layout()
    figura.savefig(destino, dpi=140, bbox_inches="tight")
    plt.close(figura)
    print(f"Gráfica guardada: {destino}", flush=True)


def generar_graficas(
    ruta_csv: Path,
    directorio: Path,
    id_sesion: str | None = None,
) -> None:
    """
    Dibuja las gráficas base más las de saturación a partir del CSV.

    Si se indica `id_sesion`, solo entran las filas de esa corrida. El CSV puede
    acumular varias sesiones; mezclarlas en la misma línea ocultaría un cambio
    de código o de carga del equipo entre ejecuciones.
    """
    if not ruta_csv.exists() or ruta_csv.stat().st_size == 0:
        print("No hay CSV con resultados; no se generan gráficas.", flush=True)
        return

    try:
        tabla = pd.read_csv(ruta_csv, encoding="utf-8-sig")
    except pd.errors.ParserError as exc:
        print(
            f"\nERROR: no se pudo leer el CSV (cabecera/filas desincronizadas).\n"
            f"  Archivo: {ruta_csv}\n"
            f"  Detalle: {exc}\n"
            "  Sugerencia: revisa o borra ese archivo, o vuelve a correr con "
            "--csv-nuevo. Si el script detectó un esquema viejo, también "
            "debió crear un resultados_benchmark_backup_*.csv.\n",
            flush=True,
        )
        return
    except OSError as exc:
        print(f"No se pudo abrir el CSV {ruta_csv}: {exc}", flush=True)
        return

    if id_sesion is not None and "id_sesion" in tabla.columns:
        tabla = tabla[tabla["id_sesion"].astype(str) == str(id_sesion)]
    if tabla.empty:
        print("La sesión no tiene filas; no se generan gráficas.", flush=True)
        return

    faltan = [columna for columna, *_resto in GRAFICAS if columna not in tabla.columns]
    if faltan:
        print(f"El CSV no tiene las columnas {faltan}; no se generan gráficas.", flush=True)
        return

    directorio.mkdir(parents=True, exist_ok=True)

    try:
        plt.style.use("seaborn-v0_8-whitegrid")
    except OSError:
        pass

    plt.rcParams.update(
        {
            "font.size": 11,
            "axes.titlesize": 13,
            "axes.labelsize": 11,
            "legend.fontsize": 10,
            "axes.unicode_minus": False,
        }
    )

    # Gráficas base: si hay varios modos, usar el más frecuente o todos juntos
    # por resolución (comportamiento histórico del informe).
    resumen = _promedios_de_sesion(tabla, ["resolucion", "cantidad_imagenes"])
    for columna, eje_y, titulo, archivo in GRAFICAS:
        _grafica_lineas_resolucion(resumen, columna, eje_y, titulo, directorio / archivo)

    _grafica_cpu_vs_procesos(tabla, directorio / "cpu_promedio_vs_procesos.png")
    _grafica_ram_secuencial_vs_retenida(
        tabla, directorio / "ram_secuencial_vs_memoria_retenida.png"
    )
    _imprimir_resumen(resumen)
    _imprimir_resumen_ram_por_proceso(tabla)


def _imprimir_resumen(resumen: pd.DataFrame) -> None:
    """Muestra en consola la tabla que después se ve en las gráficas."""
    print("\nPromedio de las repeticiones de esta sesión:", flush=True)
    columnas = [
        c
        for c in (
            "resolucion",
            "cantidad_imagenes",
            "tiempo_total_s",
            "cpu_promedio_pct",
            "ram_utilizada_mb",
            "imagenes_por_segundo",
        )
        if c in resumen.columns
    ]
    with pd.option_context("display.max_rows", 200, "display.width", 140):
        print(resumen[columnas].round(3).to_string(index=False), flush=True)


def _imprimir_resumen_ram_por_proceso(tabla: pd.DataFrame) -> None:
    """
    Resumen derivado (solo consola): RAM total / num_procesos.

    La RAM concurrente suma intérpretes hijos y no es 1:1 con secuencial.
    """
    if "num_procesos" not in tabla.columns or "ram_utilizada_mb" not in tabla.columns:
        return
    claves = [c for c in ("resolucion", "num_procesos", "modo") if c in tabla.columns]
    if "resolucion" not in claves or "num_procesos" not in claves:
        return
    resumen = (
        tabla.groupby(claves, as_index=False)["ram_utilizada_mb"].mean()
    )
    resumen["ram_por_proceso_mb"] = resumen["ram_utilizada_mb"] / resumen[
        "num_procesos"
    ].clip(lower=1)
    print(
        "\nRAM por proceso (derivada; no está en el CSV crudo):\n"
        "  Úsala para comparar 'por unidad de trabajo' entre secuencial y concurrente.",
        flush=True,
    )
    with pd.option_context("display.max_rows", 200, "display.width", 140):
        print(resumen.round(3).to_string(index=False), flush=True)


def _imprimir_guia() -> None:
    """Pistas de lectura para el informe. No clasifica solo: los números mandan."""
    print(
        """
Cómo leer el experimento (saturación)
- Tiempo total lineal + tiempo/imagen estable: el costo por imagen no se degrada.
- Aviso "posible saturación detectada": el tiempo/imagen subió >40% al subir la
  cantidad → contención, thrashing o límite de ancho de banda/caché.
- CPU vs procesos: si al pasar de 4 a "todos" la CPU ya no sube (o baja img/s),
  llegaste al techo de CPU o a contención (evidencia CPU-bound / saturación).
  Con pool persistente, el CPU% concurrente debería subir respecto al secuencial.
- RAM secuencial vs memoria_retenida: secuencial plana y retenida creciente =
  memory-bound artificial documentable; si ambas crecen, hay fugas o presión real.
- RAM concurrente ≠ RAM secuencial 1:1: cada proceso hijo trae su intérprete.
  Compara ram_utilizada_mb / num_procesos (impreso en el resumen derivado).
- CPU promedio del sistema (0-100%). Con procesos reales debería poder superar
  el ~60% típico de OpenCV multi-hilo en un solo proceso sobre CPU híbrida.
- Tres (o dos) repeticiones promediadas reducen el efecto de un pico aislado.
""",
        flush=True,
    )


def _describir_equipo() -> None:
    """Datos del equipo para copiarlos en la sección de metodología del informe."""
    ram = psutil.virtual_memory()
    frecuencia = psutil.cpu_freq()
    nucleos_fisicos = psutil.cpu_count(logical=False)
    nucleos_logicos = psutil.cpu_count(logical=True)
    print("Benchmark de procesamiento de imágenes (OpenCV)", flush=True)
    print(
        f"Equipo: {platform.system()} {platform.release()} | "
        f"{platform.processor() or 'procesador no identificado'}",
        flush=True,
    )
    print(
        f"CPU lógicos: {nucleos_logicos} | CPU físicos: {nucleos_fisicos} | "
        f"RAM total: {ram.total / (1024 ** 3):.2f} GB",
        flush=True,
    )
    if frecuencia is not None:
        maximo = f" | máximo nominal: {frecuencia.max:.0f} MHz" if frecuencia.max else ""
        print(f"Frecuencia actual: {frecuencia.current:.0f} MHz{maximo}", flush=True)
    print(
        f"OpenCV {cv2.__version__} | optimizado: {cv2.useOptimized()} | "
        f"hilos: {cv2.getNumThreads()}",
        flush=True,
    )
    print(f"Parámetros del pipeline: {PARAMETROS_TEXTO}", flush=True)
    print(f"Muestreo de CPU/RAM cada {INTERVALO_MUESTREO_S:.2f} s en un hilo aparte.", flush=True)


def _parsear_lista_resoluciones(texto: str | None) -> dict[str, tuple[int, int]] | None:
    if not texto:
        return None
    elegidas: dict[str, tuple[int, int]] = {}
    for trozo in texto.split(","):
        nombre = trozo.strip()
        if not nombre:
            continue
        if nombre not in RESOLUCIONES:
            raise SystemExit(
                f"Resolución desconocida: {nombre}. "
                f"Válidas: {', '.join(RESOLUCIONES)}"
            )
        elegidas[nombre] = RESOLUCIONES[nombre]
    return elegidas or None


def _parsear_lista_enteros(texto: str | None) -> list[int] | None:
    if not texto:
        return None
    valores = [int(x.strip()) for x in texto.split(",") if x.strip()]
    return valores or None


def _construir_argumentos(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Benchmark OpenCV con presión de CPU (procesos) y RAM (retención). "
            "Sin flags: campaña RÁPIDA de saturación (recomendado)."
        )
    )
    parser.add_argument(
        "--campana",
        action="store_true",
        help="Alias explícito de la campaña rápida (ya es el default).",
    )
    parser.add_argument(
        "--campana-completa",
        action="store_true",
        help="Campaña larga (1/2/4/todos + memoria + extremo). Mucho más lenta.",
    )
    parser.add_argument(
        "--completo",
        action="store_true",
        help="Matriz grande: todas las resoluciones y cantidades hasta 2000.",
    )
    parser.add_argument(
        "--secuencial",
        action="store_true",
        help="Solo un modo secuencial (1 proceso). Útil para baseline, no para saturar.",
    )
    parser.add_argument(
        "--extremo",
        action="store_true",
        help="Activa el perfil extremo (kernel 51x51, más pasadas) en la campaña.",
    )
    parser.add_argument(
        "--procesos",
        default=None,
        help='Número de procesos: 1, 2, 4 o "todos". Implica un solo modo (no campaña).',
    )
    parser.add_argument(
        "--memoria",
        action="store_true",
        help="Retiene decode BGR + bordes en RAM durante cada prueba.",
    )
    parser.add_argument(
        "--resoluciones",
        default=None,
        help="Lista separada por comas, ej: 1080p,4K,8K",
    )
    parser.add_argument(
        "--cantidades",
        default=None,
        help="Lista separada por comas, ej: 50,100,200,400",
    )
    parser.add_argument(
        "--repeticiones",
        type=int,
        default=None,
        help=f"Repeticiones por escenario (default {REPETICIONES}).",
    )
    parser.add_argument(
        "--sin-corte",
        action="store_true",
        help="No detener el escalado de cantidad al detectar saturación >40%.",
    )
    parser.add_argument(
        "--csv-nuevo",
        action="store_true",
        help="Respalda el CSV anterior y empieza uno limpio.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    """Punto de entrada: por defecto campaña rápida de saturación."""
    global DETENER_ESCALADO_SI_SATURA

    _configurar_consola()
    cv2.setUseOptimized(True)
    args = _construir_argumentos(argv)

    if args.sin_corte:
        DETENER_ESCALADO_SI_SATURA = False

    base = Path(__file__).resolve().parent
    ruta_csv = base / NOMBRE_CSV
    directorio_graficas = base / CARPETA_GRAFICAS
    id_sesion = datetime.now().strftime("%Y%m%d_%H%M%S")

    # Respaldo manual (--csv-nuevo) o automático si la cabecera no coincide.
    if args.csv_nuevo and ruta_csv.exists():
        respaldo = ruta_csv.with_name(
            f"resultados_benchmark_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        )
        ruta_csv.rename(respaldo)
        print(f"CSV anterior respaldado en: {respaldo}", flush=True)
    else:
        _asegurar_csv_compatible(ruta_csv)

    if args.resoluciones:
        resoluciones = _parsear_lista_resoluciones(args.resoluciones) or RESOLUCIONES_RAPIDO
    elif args.completo:
        resoluciones = RESOLUCIONES
    else:
        resoluciones = RESOLUCIONES_RAPIDO

    if args.cantidades:
        cantidades = _parsear_lista_enteros(args.cantidades) or CANTIDADES_IMAGENES
    elif args.completo:
        cantidades = CANTIDADES_COMPLETO
    else:
        cantidades = CANTIDADES_IMAGENES

    repeticiones = args.repeticiones if args.repeticiones is not None else REPETICIONES

    _aplicar_perfil_pipeline(False)
    _describir_equipo()
    print(f"Sesión: {id_sesion}", flush=True)
    print(f"CSV: {ruta_csv}", flush=True)
    print(f"Gráficas: {directorio_graficas}", flush=True)
    print(
        "\nNOTA: En modo secuencial el tiempo TOTAL suele ser LINEAL (ms/img estable).\n"
        "Eso NO es un fallo: indica costo constante por imagen. El cuello de botella\n"
        "se documenta con (a) CPU vs nº de procesos y (b) RAM retenida vs cantidad.\n"
        "El pool de procesos se crea UNA vez por modo (no por cada prueba).",
        flush=True,
    )

    # Un solo modo si el usuario pide --secuencial o --procesos explícito.
    modo_unico = args.secuencial or (args.procesos is not None) or args.memoria
    if args.campana_completa:
        campana = [dict(item) for item in CAMPANA_COMPLETA]
        if args.extremo:
            for item in campana:
                item["extremo"] = True
        print(
            f"\nCampaña COMPLETA: {len(campana)} modos. Puede tardar mucho.",
            flush=True,
        )
    elif modo_unico and not args.campana and not args.extremo:
        procs = 1 if args.secuencial else (args.procesos if args.procesos is not None else NUM_PROCESOS)
        campana = [
            {
                "num_procesos": procs,
                "mantener_en_memoria": bool(args.memoria or MANTENER_EN_MEMORIA),
                "extremo": bool(args.extremo or MODO_EXTREMO_PIPELINE),
            }
        ]
        print("\nModo único (no campaña).", flush=True)
    else:
        campana = [dict(item) for item in CAMPANA_SATURACION]
        if args.extremo:
            for item in campana:
                item["extremo"] = True
        print(
            f"\nCampaña RÁPIDA de saturación: {len(campana)} modos | "
            f"resoluciones={list(resoluciones)} | cantidades={cantidades} | "
            f"reps={repeticiones}. Objetivo orientativo: 20-30 min "
            f"(sin 8K en el preset).",
            flush=True,
        )

    inicio = time.perf_counter()
    duraciones_modos: list[float] = []
    try:
        for indice, cfg in enumerate(campana, start=1):
            procs = _resolver_num_procesos(cfg["num_procesos"])  # type: ignore[arg-type]
            mantener = bool(cfg["mantener_en_memoria"])
            extremo = bool(cfg["extremo"])
            modo = _etiqueta_modo(procs, mantener, extremo)
            print(
                f"\n########## Modo {indice}/{len(campana)}: {modo} ##########",
                flush=True,
            )
            duracion = correr_matriz_experimentos(
                ruta_csv,
                id_sesion,
                resoluciones=resoluciones,
                cantidades=cantidades,
                repeticiones=repeticiones,
                num_procesos=procs,
                mantener_en_memoria=mantener,
                extremo=extremo,
                modo=modo,
            )
            duraciones_modos.append(float(duracion))
            restantes_modos = len(campana) - indice
            if restantes_modos > 0 and duraciones_modos:
                # ETA grosero: promedio de modos ya terminados × modos que faltan.
                eta_restante = float(np.mean(duraciones_modos)) * restantes_modos
                print(
                    f"\nETA aproximado para los {restantes_modos} modos restantes: "
                    f"{eta_restante / 60.0:.1f} min "
                    f"(basado en {len(duraciones_modos)} modo(s) terminado(s)).",
                    flush=True,
                )
                if eta_restante / 60.0 > UMBRAL_ETA_ADVERTENCIA_MIN:
                    print(
                        f"ADVERTENCIA: el ETA total restante supera "
                        f"{UMBRAL_ETA_ADVERTENCIA_MIN:.0f} min. "
                        "Si no puedes esperar, cancela (Ctrl+C) y acota:\n"
                        "  python benchmark.py --procesos 4 --resoluciones 1080p "
                        "--cantidades 50,100 --repeticiones 1",
                        flush=True,
                    )
    except KeyboardInterrupt:
        print(
            "\nEjecución interrumpida. Las filas ya escritas siguen en el CSV "
            "y se grafica lo que alcanzó a terminar esta sesión.",
            flush=True,
        )
    finally:
        transcurrido = time.perf_counter() - inicio
        print(f"\nTiempo de pared de la corrida: {transcurrido:.1f} s", flush=True)
        generar_graficas(ruta_csv, directorio_graficas, id_sesion)
        _imprimir_guia()


if __name__ == "__main__":
    # Necesario en Windows para multiprocessing (spawn).
    main()
